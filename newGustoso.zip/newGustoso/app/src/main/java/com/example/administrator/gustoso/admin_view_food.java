package com.example.administrator.gustoso;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class admin_view_food extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_food);
    }
}
